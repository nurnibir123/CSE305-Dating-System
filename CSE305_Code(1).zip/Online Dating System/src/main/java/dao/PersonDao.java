package dao;

import model.Customer;

import java.util.ArrayList;
import java.util.List;

public class PersonDao {

//	Write functions in order to utilise the Person model

}
